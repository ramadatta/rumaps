# RUMAPS

RUMAPS is a Python package designed to create refined UMAP visualizations with clean labeling and interactive exploration. Whether you're visualizing large-scale datasets or fine-tuning specific clusters, RUMAPS provides intuitive tools to enhance your data visualization workflow.

---

## Key Features
- **Polished UMAP Visualizations**: Generate clean and well-structured UMAP plots with custom labeling.
- **Interactive Exploration**: Add hover text, search functionality, and custom layers to dive deeper into your data.
- **Streamlined Integration**: Seamlessly integrate RUMAPS into your existing data analysis pipelines.

---

## Installation

Install RUMAPS via pip:

```bash
pip install rumaps
```

---

## Usage

### Basic Interactive UMAP
Here's how to create a basic UMAP visualization with hover functionality:

```python
import rumaps

# Assuming `adata` is your AnnData object
rumaps.interactive.interactive_umap(
    adata=adata,
    labels_key="cluster_labels",  # Column with cluster labels
    title="Interactive UMAP Visualization",
    hover_columns=["gene_expression", "cell_type", "sample_batch"],  # Columns to display on hover
    save_path="interactive_umap.html"
)
```

### Advanced Usage with Multiple Layers
You can add multiple label layers for a more detailed visualization:

```python
rumaps.interactive.interactive_umap(
    adata=adata,
    labels_key="main_cluster",
    label_layers=["sub_cluster", "batch_info"],  # Add additional layers
    title="Advanced UMAP Visualization",
    hover_columns=["gene1", "gene2", "metadata"],
    save_path="advanced_umap.html"
)
```

---

## Dependencies
RUMAPS requires the following Python packages:
- `numpy`
- `pandas`
- `matplotlib`
- `datamapplot`
- `scanpy`

Install these dependencies using:

```bash
pip install -r requirements.txt
```

---

## Contributing

We welcome contributions from the community! If you have suggestions, bug fixes, or enhancements, feel free to open an issue or submit a pull request.

---

## License

RUMAPS is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.

---

## Acknowledgments

Special thanks to the open-source community and contributors who made this package possible.

---

## Contact

For any questions or issues, please contact us at [your_email@example.com].
